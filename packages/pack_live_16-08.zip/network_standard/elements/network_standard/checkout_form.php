<?php defined('C5_EXECUTE') or die(_("Access Denied."));
extract($vars);
?>

<p><?= t("Click \"Complete Order\" to Proceed to the Network Payment Website.")?></p>
