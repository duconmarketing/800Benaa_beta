<div class="left_bar">
         <div class="left_single">
        	 <h5 class="account"><a href="<?= URL::to('/account') ?>">My Account</a></h5>
			 <a href="" class="account-pull"></a>
             <ul class="account-side-nav">
                <li class="details"><a href="<?= URL::to('/account/edit_profile') ?>">My Details</a></li>
				<li class="orders"><a href="<?= URL::to('/account/my_orders') ?>">My Orders</a></li>
				
             </ul>
         </div>
 </div>