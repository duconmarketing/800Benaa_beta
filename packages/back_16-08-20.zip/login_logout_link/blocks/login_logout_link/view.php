<?php  defined('C5_EXECUTE') or die("Access Denied."); ?>
<<?php  echo $formatting;?> class="login-logout-link"><a href="<?php  echo $url;?>"><?php  echo h($label)?></a></<?php  echo $formatting;?>>
