<?php defined('C5_EXECUTE') or die(_("Access Denied."));
extract($vars);
?>

<p><?= t("An invoice will be sent to you upon ordering, Either you can pay by cash or through Credit Card at Site")?></p>
