<?php
defined('C5_EXECUTE') or die("Access Denied.");
$this->inc('form.php', array('showAddToCart'=>true,'showPageLink'=>true,'showDescription'=>true, 'showPrice'=>true, 'showName'=>true));
