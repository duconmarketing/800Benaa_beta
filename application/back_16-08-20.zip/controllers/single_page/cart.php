<?php

namespace Application\Controller\SinglePage;

use PageController;
use Config;
use Loader;
use Page;
use Core;
use Concrete\Core\Mail\Service as MailService;
use \Concrete\Package\CommunityStore\Src\CommunityStore\Product\Product as StoreProduct;
use \Concrete\Package\CommunityStore\Src\CommunityStore\Cart\Cart as StoreCart;
use \Concrete\Package\CommunityStore\Src\CommunityStore\Discount\DiscountRule as StoreDiscountRule;
use \Concrete\Package\CommunityStore\Src\CommunityStore\Discount\DiscountCode as StoreDiscountCode;
use \Concrete\Package\CommunityStore\Src\CommunityStore\Utilities\Calculator as StoreCalculator;
use Concrete\Package\CommunityStore\Src\CommunityStore\Product\ProductList as StoreProductList;
use \Application\Src\MailExtended\MailService as MailService2;

defined('C5_EXECUTE') or die(_("Access Denied."));

class Cart extends PageController {

    public function view() {
        //die('sdfdsf');
        if (Config::get('community_store.shoppingDisabled') == 'all') {
            $this->redirect("/");
        }

        $codeerror = false;
        $codesuccess = false;

        if ($this->post()) {
            if ($this->post('action') == 'code') {
                $codeerror = false;
                $codesuccess = false;

                if ($this->post('code')) {
                    $codesuccess = StoreDiscountCode::storeCartCode($this->post('code'));
                    $codeerror = !$codesuccess;
                } else {
                    StoreDiscountCode::clearCartCode();
                }
            }

            if ($this->post('action') == 'update') {
                $data = $this->post();

                if (is_array($data['instance'])) {
                    $result = StoreCart::updateMutiple($data);
                    $quantity = 0;
                    foreach ($data['pQty'] as $q) {
                        $quantity += $q;
                    }

                    $added = 0;
                    foreach ($result as $r) {
                        $added += $r['added'];
                    }
                } else {
                    $result = StoreCart::update($data);
                    $added = $result['added'];
                    $quantity = (int) $data['pQty'];
                }

                $returndata = array('success' => true, 'quantity' => $quantity, 'action' => 'update', 'added' => $added);
            }
            $email = $this->post('quote_email');

            if ($this->post('action') == 'quote') {
                //Check Quote mail exist
                //if exist send Quote
                self::sendQuote();
            }

            if ($this->post('action') == 'clear') {
                StoreCart::clear();
                $returndata = array('success' => true, 'action' => 'clear');
            }

            if ($this->post('action') == 'remove') {
                $data = $this->post();
                if (isset($data['instance'])) {
                    StoreCart::remove($data['instance']);
                    $returndata = array('success' => true, 'action' => 'remove');
                }
            }
        }

        $this->set('actiondata', $returndata);
        $this->set('codeerror', $codeerror);
        $this->set('codesuccess', $codesuccess);

        $this->set('cart', StoreCart::getCart());
        $this->set('discounts', StoreCart::getDiscounts());

        $totals = StoreCalculator::getTotals();

        if (StoreCart::isShippable()) {
            $this->set('shippingEnabled', true);

            if (\Session::get('community_store.smID')) {
                $this->set('shippingtotal', $totals['shippingTotal']);
            } else {
                $this->set('shippingtotal', false);
            }
        } else {
            $this->set('shippingEnabled', false);
        }

        $this->set('total', $totals['total']);
        $this->set('subTotal', $totals['subTotal']);

        $this->requireAsset('javascript', 'jquery');
        $js = \Concrete\Package\CommunityStore\Controller::returnHeaderJS();
        $this->addFooterItem($js);
        $this->requireAsset('javascript', 'community-store');
        $this->requireAsset('css', 'community-store');

        $discountsWithCodesExist = StoreDiscountRule::discountsWithCodesExist();
        $this->set("discountsWithCodesExist", $discountsWithCodesExist);
    }

    public function add() {
        $data = $this->post();
        $result = StoreCart::add($data);

        $added = $result['added'];

        $error = 0;

        if ($result['error']) {
            $error = 1;
        }

        $product = StoreProduct::getByID($data['pID']);
        $productdata['pAutoCheckout'] = $product->autoCheckout();
        $productdata['pName'] = $product->getName();

        $returndata = array('quantity' => (int) $data['quantity'], 'added' => $added, 'product' => $productdata, 'action' => 'add', 'error' => $error);
        echo json_encode($returndata);
        exit();
    }

    /* public function getQuote($det){



      } */

    public function code() {
        StoreDiscountCode::storeCartCode($this->post('code'));
        exit();
    }

    public function update() {
        $data = $this->post();

        if (is_array($data['instance'])) {
            $result = StoreCart::updateMutiple($data);
            $quantity = 0;
            foreach ($data['pQty'] as $q) {
                $quantity += $q;
            }

            $added = 0;
            foreach ($result as $r) {
                $added += $r['added'];
            }
        } else {
            $result = StoreCart::update($data);
            $added = $result['added'];
            $quantity = (int) $data['pQty'];
        }

        $returndata = array('success' => true, 'quantity' => $quantity, 'action' => 'update', 'added' => $added);

        echo json_encode($returndata);
        exit();
    }

    public function remove() {
        $instanceID = $_POST['instance'];
        StoreCart::remove($instanceID);
        $returndata = array('success' => true, 'action' => 'remove');
        echo json_encode($returndata);
        exit();
    }

    public function clear() {
        StoreCart::clear();
        $returndata = array('success' => true, 'action' => 'clear');
        echo json_encode($returndata);
        exit();
    }

    public function sendQuote() {

        $cart = StoreCart::getCart();

        Loader::Element('print_spa/download_pdf', array(
            'cart' => $cart, 'postValues' => $_POST));
    }

    public function ajaxSearch() {
        $data = $this->post();
        $key = $data['key'];

        $products = new StoreProductList();
        $products->setSortBy($this->sortOrder);

        if ($key != '') {
            $products->setSearch($key);
        }

        $products->setItemsPerPage(12);
        $products->setFeaturedOnly($this->showFeatured);
        $products->setSaleOnly($this->showSale);
        $products->setShowOutOfStock($this->showOutOfStock);
        $products->setGroupMatchAny($this->groupMatchAny);
        $paginator = $products->getPagination();
        $pagination = $paginator->renderDefaultView();
        $products = $paginator->getCurrentPageResults();

        foreach ($products as $product) {
            $product->setInitialVariation();
        }

        $html = $this->createSearchHTML($products);

        $returndata = array('html' => $html);
        echo json_encode($returndata);
        exit();
    }

    public function createSearchHTML($products) {
        $html = '';
        $html .= '<div class="row">';
        if ($products) {
            foreach ($products as $product) {
                $imgObj = $product->getImageObj();
                $thumb = Core::make('helper/image')->getThumbnail($imgObj, 150, 140, true);
                $html .= '<div class="store-product-list-item_ajx col-md-3 col-sm-3 col-xs-6">';
                $html .= '<div class="product_item_ajx pro hvr-float">';
                $html .= '<a href="' . ($product->getAttribute('redirect_to_site') && $product->getAttribute('redirect_url') != '' ? $product->getAttribute('redirect_url') : \URL::to(Page::getByID($product->getPageID()))) . '">';

                $html .= '<img src="' . $thumb->src . '" class="img-responsive" alt="' . $product->getName() . '"/>';

                $html .= '</a>';

                $html .= '</div>';
                $html .= '<a class="a_title_ajx" href="' . ($product->getAttribute('redirect_to_site') && $product->getAttribute('redirect_url') != '' ? $product->getAttribute('redirect_url') : \URL::to(Page::getByID($product->getPageID()))) . '">';
                $html .= $product->getName();
                $html .= '</a>';

                $html .= '<h6>';
                $salePrice = $product->getSalePrice();
                if (isset($salePrice) && $salePrice != "") {
                    $html .= $product->getFormattedSalePrice() . '<span style="font-size: 14px;color: #000;text-transform: none;font-weight:normal;"> Ex VAT</span><br>';
                    $html .= '<span class="store-original-price" style="color: #999;font-size: 13px;">' . $product->getFormattedOriginalPrice() . '</span>';
                } else {
                    $html .= $product->getFormattedPrice() . '<span style="font-size: 12px;color: #000;text-transform: none;font-weight:normal;"> Ex VAT</span>';
                }
                $html .= '</h6>';

                $html .= '</div>';
            }
            $html .= '</div>';
            $html .= '<div class="row mb-3"><div class="col-md-12"><button class="btn btn-primary" style="background-color: #ec7c05;border-color: #ec7c05;margin: 10px;" type="submit">View All results...</button></div></div>';
        } else {
            $html .= '<h4>No products were found !!! </h4></div>';
        }
        return $html;
    }

    public function inquiry(){
        try {
            $userEmail=$_POST['userEmail'];
            if(is_array($_FILES)) {
                move_uploaded_file( $_FILES['attachmentFile']['tmp_name'], DIR_BASE . '/application/inquiry/' . $_FILES['attachmentFile']['name']);
                $filepath = DIR_BASE . '/application/inquiry/' . $_FILES['attachmentFile']['name'];
            }
            $mh = new MailService2();
            $mh->to('toafsar@gmail.com');
            $mh->from('inquiry@800benaa.com');
            $mh->replyto($userEmail);
            $mh->setBodyHTML('<html><body>Hi, <br /><br />You have an inquiry attachment uploaded from the website.<br /><br /> <b>Email - ' . $userEmail . '</b><br /><br />Please fine the inquiry attached.</body></html>');
            $mh->setSubject(t('Inquiry from 800Benaa website'));
            $afiles = array();
            $pdffilepath = DIR_BASE . '/application/inquiry/' . $pdfname;
            $afiles[0]['path'] = $filepath;
            //$afiles[0]['mime'] = 'application/pdf';
            $afiles[0]['mime'] = 'text/html';
            $afiles[0]['name'] = basename($filepath);
            $mh->addAttachments($afiles);
            $mh->sendMail();
            die('Mail has been sent');
        } catch (Exception $e) {
            die("Mail could not be sent. Mailer Error: {$mail->ErrorInfo}");
        }
    }

}
