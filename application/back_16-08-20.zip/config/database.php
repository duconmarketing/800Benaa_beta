<?php

return array(

    'default-connection' => 'concrete',

    'connections' => array(

        'concrete' => array(

            'driver' => 'c5_pdo_mysql',

            'server' => 'localhost',

            'database' => 'e5f4h7y9_800benaa_beta',

            'username' => 'e5f4h7y9_benaabe',

            'password' => '(g2N6v$M73,F',

            'charset' => 'utf8',

        ),

    ),

);
