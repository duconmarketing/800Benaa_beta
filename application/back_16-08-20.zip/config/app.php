<?php

return array(
'theme_paths'         => array(
 '/login' => 'build',    
    '/register' => 'build',
    '/account'          => 'build',
    '/account/*'        => 'build',
)

);
