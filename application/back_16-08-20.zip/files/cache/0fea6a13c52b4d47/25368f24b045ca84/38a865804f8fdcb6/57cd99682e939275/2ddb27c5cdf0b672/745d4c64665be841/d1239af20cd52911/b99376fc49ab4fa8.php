<?php 
/* Cachekey: cache/stash_default/doctrine/doctrinenamespacecachekey[dc2_87e4600c8fdf9f40c295ece34ca67de0_]/ */
/* Type: array */



$loaded = true;
$expiration = 1597620896;

$data = array();

/* Child Type: integer */
$data['return'] = 1;

/* Child Type: integer */
$data['createdOn'] = 1597219931;
