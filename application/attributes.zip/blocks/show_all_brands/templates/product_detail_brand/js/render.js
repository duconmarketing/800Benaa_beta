$(document).ready(function(){
	$('.scrollbar-inner').slimScroll({
        height: '345px',
		railVisible: true,
    	alwaysVisible: true,
		color: '#845aa3',
		railOpacity: 0.2,
    });
});