<?php

return array(

    'default-connection' => 'concrete',

    'connections' => array(

        'concrete' => array(

            'driver' => 'c5_pdo_mysql',

            'server' => 'localhost',

            // 'database' => 'e5f4h7y9_vbuild',
            // 'database' => 'e5f4h7y9_800benaa',
            'database' => 'e5f4h7y9_800benaa_live',

            // 'username' => 'e5f4h7y9_vbuild',
            // 'username' => 'e5f4h7y9_benaa',
            'username' => 'e5f4h7y9_bena_lv',

            // 'password' => 'p6lo7!]-BEud',
            // 'password' => '800benaa123',
            'password' => 'FV3~r-HNSJFo',

            'charset' => 'utf8',

        ),

    ),

);
